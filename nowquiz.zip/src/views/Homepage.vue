<template>
  <div class="BrowserSafariBigSurLight" style="margin-right: 0px; background: white">
    <div class="Body" style="width: 1280px; height: 779px; left: 200px; position: absolute; background: white"></div>
    <div class="408" style="left: 309px; top: 315px; position: absolute; text-align: center"><span style="color: black; font-size: 64px; font-family: Lantinghei SC; font-weight: 400; word-wrap: break-word">智慧题海，<br/>解析</span><span style="color: black; font-size: 64px; font-family: Alex Brush; font-weight: 400; word-wrap: break-word">408</span><span style="color: black; font-size: 64px; font-family: Lantinghei SC; font-weight: 400; word-wrap: break-word">。</span></div>
    <div class="Ellipse1" style="width: 382px; height: 382px; left: 988px; top: 169px; position: absolute; background: rgba(243, 114, 114, 0.80); box-shadow: 70px 70px 70px; border-radius: 9999px; filter: blur(70px)"></div>
    <div class="Ellipse3" style="width: 220px; height: 220px; left: 1123px; top: 456px; position: absolute; background: rgba(176, 164, 231, 0.80); box-shadow: 70px 70px 70px; border-radius: 9999px; filter: blur(70px)"></div>
    <div class="Ellipse2" style="width: 316px; height: 317px; left: 880px; top: 415px; position: absolute; background: #80CBFF; box-shadow: 70px 70px 70px; border-radius: 9999px; filter: blur(70px)"></div>
    <div class="Ellipse4" style="width: 130px; height: 124px; left: 899px; top: 394px; position: absolute; background: #4BE1B3; box-shadow: 50px 50px 50px; border-radius: 9999px; filter: blur(50px)"></div>
    <div class="Ellipse5" style="width: 204px; height: 205px; left: 899px; top: 239px; position: absolute; background: #F7B36E; box-shadow: 80px 80px 80px; border-radius: 9999px; filter: blur(80px)"></div>
    <div class="Group2" style="width: 273.51px; height: 162px; left: 1000.76px; top: 206.87px; position: absolute">
      <div class="Rectangle1" style="width: 273.51px; height: 162px; left: 0px; top: 0px; position: absolute; background: rgba(255, 255, 255, 0.40); border-radius: 18px; border: 1px rgba(255, 255, 255, 0.40) solid; backdrop-filter: blur(12px)"></div>
      <div style="width: 111px; height: 24px; left: 71.24px; top: 28.13px; position: absolute; color: rgba(72, 172, 199, 0.70); font-size: 20px; font-family: Lantinghei SC; font-weight: 400; word-wrap: break-word">操作系统</div>
      <div style="width: 216px; height: 18px; left: 26.24px; top: 130.13px; position: absolute; color: rgba(72, 172, 199, 0.70); font-size: 15px; font-family: Times new roman; font-weight: 400; word-wrap: break-word">进程管理/内存管理/文件管理/...</div>
      <div class="Ellipse6" style="width: 42.08px; height: 42.08px; left: 16.83px; top: 19.99px; position: absolute; background: conic-gradient(from 180deg at 0.00% 100.00%, rgba(255, 255, 255, 0.40) 0deg, rgba(0, 0, 0, 0.35) 81deg, rgba(255, 255, 255, 0.40) 152deg, rgba(0, 0, 0, 0.35) 214deg, rgba(255, 255, 255, 0.40) 289deg, rgba(0, 0, 0, 0.35) 360deg); box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 9999px"></div>
      <div class="Ellipse7" style="width: 35.77px; height: 35.77px; left: 196.72px; top: 23.14px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
      <div class="Ellipse8" style="width: 35.77px; height: 35.77px; left: 214.60px; top: 23.14px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
    </div>
    <div class="Group1" style="width: 273.51px; height: 162px; left: 864px; top: 348.89px; position: absolute">
      <div class="Rectangle1" style="width: 273.51px; height: 162px; left: 0px; top: 0px; position: absolute; background: rgba(255, 255, 255, 0.40); border-radius: 18px; border: 1px rgba(255, 255, 255, 0.40) solid; backdrop-filter: blur(12px)"></div>
      <div style="width: 99px; height: 24px; left: 72px; top: 29.11px; position: absolute; color: rgba(72, 172, 199, 0.70); font-size: 20px; font-family: Times new roman; font-weight: 700; word-wrap: break-word">数据结构</div>
      <div style="width: 182px; height: 18px; left: 26px; top: 130.11px; position: absolute; color: rgba(72, 172, 199, 0.70); font-size: 15px; font-family: Times new roman; font-weight: 400; word-wrap: break-word">线性表/栈和队列/图/...</div>
      <div class="Ellipse6" style="width: 42.08px; height: 42.08px; left: 16.83px; top: 19.99px; position: absolute; background: conic-gradient(from 180deg at 0.00% 100.00%, rgba(255, 255, 255, 0.40) 0deg, rgba(0, 0, 0, 0.35) 81deg, rgba(255, 255, 255, 0.40) 152deg, rgba(0, 0, 0, 0.35) 214deg, rgba(255, 255, 255, 0.40) 289deg, rgba(0, 0, 0, 0.35) 360deg); box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 9999px"></div>
      <div class="Ellipse7" style="width: 35.77px; height: 35.77px; left: 196.72px; top: 23.14px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
      <div class="Ellipse8" style="width: 35.77px; height: 35.77px; left: 214.60px; top: 23.14px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
    </div>
    <div class="Group3" style="width: 273.51px; height: 162px; left: 1071.24px; top: 446.72px; position: absolute">
      <div class="Rectangle1" style="width: 273.51px; height: 162px; left: 0px; top: 0px; position: absolute; background: rgba(255, 255, 255, 0.40); border-radius: 18px; border: 1px rgba(255, 255, 255, 0.40) solid; backdrop-filter: blur(12px)"></div>
      <div style="width: 114px; height: 24px; left: 71.76px; top: 28.28px; position: absolute; color: rgba(72, 172, 199, 0.70); font-size: 20px; font-family: Times new roman; font-weight: 700; word-wrap: break-word">计算机网络</div>
      <div style="width: 206px; height: 18px; left: 26.76px; top: 130.28px; position: absolute; color: rgba(72, 172, 199, 0.70); font-size: 15px; font-family: Times new roman; font-weight: 400; word-wrap: break-word">物理层/数据链路层/网络层/...</div>
      <div class="Ellipse6" style="width: 42.08px; height: 42.08px; left: 16.83px; top: 19.99px; position: absolute; background: conic-gradient(from 180deg at 0.00% 100.00%, rgba(255, 255, 255, 0.40) 0deg, rgba(0, 0, 0, 0.35) 81deg, rgba(255, 255, 255, 0.40) 152deg, rgba(0, 0, 0, 0.35) 214deg, rgba(255, 255, 255, 0.40) 289deg, rgba(0, 0, 0, 0.35) 360deg); box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25); border-radius: 9999px"></div>
      <div class="Ellipse7" style="width: 35.77px; height: 35.77px; left: 196.72px; top: 23.14px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
      <div class="Ellipse8" style="width: 35.77px; height: 35.77px; left: 214.60px; top: 23.14px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
    </div>
    <div class="Ellipse9" style="width: 84px; height: 84px; left: 1234px; top: 309px; position: absolute; opacity: 0.99; background: linear-gradient(180deg, #EE6363 0%, #FB9899 100%); border-radius: 9999px; border: 1px #B7161B solid"><div style="color: white; font-size: 24px; font-family: Times new roman; font-weight: 700; word-wrap: break-word; margin-top: 25px;">✔</div></div>
    <div class="Ellipse13" style="width: 49px; height: 49px; left: 936px; top: 276px; position: absolute; opacity: 0.99; background: linear-gradient(180deg, #F1BE3B 0%, #EFD5A1 100%); border-radius: 9999px; border: 1px #E5A933 solid"></div>
    <div class="Ellipse10" style="width: 84px; height: 84px; left: 1026px; top: 591px; position: absolute; background: linear-gradient(138deg, rgba(255, 255, 255, 0.40) 0%, rgba(224, 250, 255, 0.40) 100%); border-radius: 9999px; border: 1px rgba(255, 255, 255, 0.40) solid; backdrop-filter: blur(12px)"></div>
    <div class="Ellipse11" style="width: 37px; height: 37px; left: 1086px; top: 638px; position: absolute; background: linear-gradient(314deg, #4AD3B2 0%, #81EDD3 100%); border-radius: 9999px; border: 1px #57FCD4 solid"></div>
    <div class="Group4" style="width: 114px; height: 41px; left: 311px; top: 555px; position: absolute; cursor: pointer;" @click="goToQuestion()">
      <div class="Rectangle3" style="width: 114px; height: 41px; left: 0px; top: 0px; position: absolute; background: #049DDF; border-radius: 8px"></div>
      <div style="left: 17px; top: 10px; position: absolute; text-align: center; color: white; font-size: 20px; font-family: Heiti SC; font-weight: 400; word-wrap: break-word">在线问答</div>
    </div>
    <div class="Group5" style="width: 114px; height: 41px; left: 452px; top: 555px; position: absolute; cursor: pointer;" @click="goToPaper()">
      <div class="Rectangle3" style="width: 114px; height: 41px; left: 0px; top: 0px; position: absolute; background: #049DDF; border-radius: 8px"></div>
      <div style="left: 17px; top: 10px; position: absolute; text-align: center; color: white; font-size: 20px; font-family: Heiti SC; font-weight: 400; word-wrap: break-word">生成试卷</div>
    </div>
    <div class="Nowquiz" style="left: 41px; top: 30px; position: absolute; text-align: center; color: black; font-size: 24px; font-family: Audiowide; font-weight: 400; word-wrap: break-word">NowQuiz</div>
    <div class="Ellipse15" style="width: 10px; height: 10px; left: 1042px; top: 628px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
    <div class="Ellipse16" style="width: 10px; height: 10px; left: 1062px; top: 628px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
    <div class="Ellipse17" style="width: 10px; height: 10px; left: 1083px; top: 628px; position: absolute; background: rgba(255, 255, 255, 0.50); border-radius: 9999px"></div>
    <div style="width: 178px; height: 27px; left: 311px; top: 500px; position: absolute; color: #737373; font-size: 13px; font-family: Heiti SC; font-weight: 400; word-wrap: break-word">海量题库，等你探索...</div>
    <div style="width: 19px; height: 22px; left: 951px; top: 290px; position: absolute; text-align: center; color: white; font-size: 24px; font-family: Times new roman; font-weight: 700; word-wrap: break-word"><div>?</div></div>
    <div style="width: 19px; height: 22px; left: 1095px; top: 646px; position: absolute; text-align: center; color: white; font-size: 24px; font-family: Times new roman; font-weight: 700; word-wrap: break-word"><div>?</div></div>
  </div>
</template>

<script>
export default({
  name: 'homepage',
  methods: {
    goToPaper() {
      this.$router.push('/paper')
    },
    goToQuestion() {
      this.$router.push('/question')
    }
  }
})
</script>

<style>
@font-face {
  font-family: Audiowide;
  src: url('../assets/Audiowide-Regular.ttf');
}
@font-face {
  font-family: Alex Brush;
  src: url('../assets/AlexBrush-Regular.ttf');
}
@font-face {
  font-family: Heiti SC;
  src: url('../assets/heiti-sc-medium.ttf');
}
@font-face {
  font-family: Arial;
  src: url('../assets/arialbd.ttf');
}
</style>
